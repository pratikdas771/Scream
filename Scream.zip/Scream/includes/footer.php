    <footer>
        <a href = "about.php">2020. Rajarshi Saha</a>
    </footer>
    <script src="./public/jquery.js"></script>
    <script src = "./public/index.js"></script>
    </body>
</html>