<!DOCTYPE html>

<html>
    <head>
        <title>Scream</title>
        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
        <link rel = "icon" type = "image/gif" href = "https://i.pinimg.com/originals/25/79/99/25799939906655b8796193a8f4ba9b3b.gif"/>
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital@1&display=swap" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "./public/style.css"/>
    </head>
    <body>
    