<?php
    $server = 'localhost';
    $user = 'root';
    $pass = '';
    $dbName = 'scream';

    $conn = mysqli_connect($server,$user,$pass,$dbName);
?>