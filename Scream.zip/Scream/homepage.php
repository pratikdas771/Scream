<?php
    require_once("./includes/connection.php");
    require_once("./includes/session.php");
    require_once("./includes/header.php");
    require_once("./includes/loader.php");
    require_once("./includes/nav.php");
    ?>
    <div class = "homepage">
        <h1>Homepage</h1>
    </div>
    <?php
    require_once("./includes/footer.php");
?>